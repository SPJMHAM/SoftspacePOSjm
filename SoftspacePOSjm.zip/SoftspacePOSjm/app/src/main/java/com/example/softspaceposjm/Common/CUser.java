package com.example.softspaceposjm.Common;

import com.example.softspaceposjm.Model.User;

public class CUser {

    public static User currentUser;

}
