package com.example.softspaceposjm.Common;


public class DJobName {
    //   public static ListInfo RegisterEventLocation;



    public static String EName;


    public DJobName(){

    }

    public DJobName(String EName) {
        this.EName = EName;
    }

    public String getEName() {
        return EName;
    }

    public void setEName(String EName) {
        this.EName = EName;
    }
}
