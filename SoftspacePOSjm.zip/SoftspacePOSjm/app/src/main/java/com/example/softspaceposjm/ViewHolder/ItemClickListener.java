package com.example.softspaceposjm.ViewHolder;

import android.view.View;

interface ItemClickListener {
    void onClick(View view, int position, boolean isLongClick);
}
