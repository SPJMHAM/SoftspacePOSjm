package com.example.softspaceposjm.ViewHolder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.softspaceposjm.R;

public class List extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
    }
}